# 📐 Mathe-Training 6

Übungs-App für die 6. Klasse (Mittelschule Bayern) zu **Brüchen** und **Flächeninhalt**.
Läuft direkt im Browser – auf PC, Tablet und Handy, ohne Anmeldung und ohne Installation.

## Die fünf Übungen

| Nr. | Übung | Bedienung |
|----|------|-----------|
| 1 | **Bruchteile ablesen** – 20 Flächen, gefärbter Anteil wird als Bruch eingetragen (Feld mit Zähler, Bruchstrich, Nenner) | Eintippen, dann „Überprüfen“ |
| 2 | **Brüche zuordnen** – 20 Darstellungen, 25 Bruchkarten (5 passen zu keiner Darstellung) | Karte auf die Figur ziehen |
| 3 | **Flächeninhalt** – 20 bemaßte Rechtecke/Quadrate, 20 Karten mit cm²-Angaben | Karte auf das Rechteck ziehen |
| 4 | **Flächeninhaltsgleiche Vierecke** – 25 Vierecke, 10 Paare + 5 ohne Partner (teils mit dm/mm) | Viereck auf seinen Partner ziehen – richtige Paare blinken grün |
| 5 | **Kürzen & Erweitern** – 30 Brüche, 11 Paare (22 Brüche) + 8 ohne Partner | Bruch auf den gleichwertigen Bruch ziehen |

Bedienung auf dem Tablet/Handy: Karte **kurz festhalten**, dann ziehen – oder einfach erst die Karte und dann das Ziel **antippen**.
Bei Übung 1 werden auch gleichwertige Brüche (z. B. 2/8 statt 1/4) als richtig gewertet.

## Druckversion

Über die Kachel **„Druckversion“** (`print.html`) lassen sich alle Übungen als A4-Arbeitsblätter drucken –
wahlweise mit **Lösungsblatt** und **QR-Code-Seite** (zum Aufhängen im Klassenzimmer).

## QR-Code / Online stellen (GitHub Pages)

1. Auf GitHub im Repository: **Settings → Pages**
2. Unter *Build and deployment* → *Source*: **Deploy from a branch**
3. Branch auswählen (z. B. `main` bzw. den Branch mit der App) und Ordner **`/ (root)`** → **Save**
4. Nach 1–2 Minuten ist die App erreichbar unter
   `https://michaeldrosihn-dot.github.io/New/`
5. Diese Adresse öffnen → Kachel **„QR-Code“** → Code anzeigen oder ausdrucken. Der QR-Code wird automatisch für die aktuelle Adresse erzeugt.

Hinweis: Für GitHub Pages mit einem kostenlosen Konto muss das Repository öffentlich sein.

## Technik

Reines HTML/CSS/JavaScript, keine Abhängigkeiten außer dem mitgelieferten QR-Code-Generator
(`lib/qrcode.js`, Kazuhiko Arase, MIT-Lizenz). Die Aufgaben stehen in `js/data.js` und können dort angepasst werden.
