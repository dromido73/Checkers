// Hilfsfunktionen: Zufall mit Startwert, SVG-Figuren, Rechtecke und Bruch-Darstellung.

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle(arr, rand = Math.random) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function sameValue(a, b) {
  return a[0] * b[1] === a[1] * b[0];
}

function shapeTotal(s) {
  switch (s.t) {
    case 'circle': case 'bar': return s.n;
    case 'grid': return s.r * s.c;
    case 'hex': return 6;
    case 'tri': return s.m * s.m;
    case 'half': return 2;
  }
}

function shapeFraction(s) {
  return [s.k, shapeTotal(s)];
}

function coloredParts(s) {
  const idx = [...Array(shapeTotal(s)).keys()];
  const sel = s.seed == null ? idx.slice(0, s.k) : shuffle(idx, mulberry32(s.seed)).slice(0, s.k);
  return new Set(sel);
}

const r2 = v => Math.round(v * 100) / 100;

function poly(pts, on) {
  return `<polygon points="${pts.map(p => r2(p[0]) + ',' + r2(p[1])).join(' ')}" class="${on ? 'on' : 'off'}"/>`;
}

function shapeSVG(s) {
  const on = coloredParts(s);
  let body = '';
  if (s.t === 'circle') {
    const R = 45;
    const pt = deg => [50 + R * Math.cos(deg * Math.PI / 180), 50 + R * Math.sin(deg * Math.PI / 180)];
    for (let i = 0; i < s.n; i++) {
      const [x0, y0] = pt(-90 + i * 360 / s.n);
      const [x1, y1] = pt(-90 + (i + 1) * 360 / s.n);
      body += `<path d="M50 50 L${r2(x0)} ${r2(y0)} A${R} ${R} 0 0 1 ${r2(x1)} ${r2(y1)}Z" class="${on.has(i) ? 'on' : 'off'}"/>`;
    }
  } else if (s.t === 'grid') {
    const cell = Math.min(90 / s.c, 90 / s.r);
    const ox = (100 - cell * s.c) / 2, oy = (100 - cell * s.r) / 2;
    for (let y = 0; y < s.r; y++) {
      for (let x = 0; x < s.c; x++) {
        const i = y * s.c + x;
        body += `<rect x="${r2(ox + x * cell)}" y="${r2(oy + y * cell)}" width="${r2(cell)}" height="${r2(cell)}" class="${on.has(i) ? 'on' : 'off'}"/>`;
      }
    }
  } else if (s.t === 'bar') {
    const w = 94 / s.n;
    for (let i = 0; i < s.n; i++) {
      body += `<rect x="${r2(3 + i * w)}" y="32" width="${r2(w)}" height="36" class="${on.has(i) ? 'on' : 'off'}"/>`;
    }
  } else if (s.t === 'hex') {
    const v = [...Array(6).keys()].map(i => {
      const a = (-90 + i * 60) * Math.PI / 180;
      return [50 + 46 * Math.cos(a), 50 + 46 * Math.sin(a)];
    });
    for (let i = 0; i < 6; i++) body += poly([[50, 50], v[i], v[(i + 1) % 6]], on.has(i));
  } else if (s.t === 'tri') {
    const m = s.m, top = 11, h = 78;
    const P = (i, j) => [50 - i * (45 / m) + j * (90 / m), top + i * h / m];
    let n = 0;
    for (let i = 0; i < m; i++) {
      for (let j = 0; j <= i; j++) body += poly([P(i, j), P(i + 1, j), P(i + 1, j + 1)], on.has(n++));
      for (let j = 0; j < i; j++) body += poly([P(i, j), P(i, j + 1), P(i + 1, j + 1)], on.has(n++));
    }
  } else if (s.t === 'half') {
    body += poly([[8, 8], [92, 8], [92, 92]], on.has(0));
    body += poly([[8, 8], [8, 92], [92, 92]], on.has(1));
  }
  return `<svg class="shape" viewBox="0 0 100 100" role="img" aria-label="Figur">${body}</svg>`;
}

// Rechteck mit Bemaßung. scale = Pixel pro cm
function rectSVG(r, scale) {
  const w = r.w * scale, h = r.h * scale;
  const W = w + 62, H = h + 34;
  const wl = r.wl || r.w + ' cm', hl = r.hl || r.h + ' cm';
  return `<svg class="rect" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Rechteck ${wl} mal ${hl}">` +
    `<rect x="6" y="6" width="${w}" height="${h}"/>` +
    `<text x="${6 + w / 2}" y="${h + 26}" text-anchor="middle">${wl}</text>` +
    `<text x="${w + 12}" y="${6 + h / 2 + 5}">${hl}</text></svg>`;
}

function fracHTML(f) {
  return `<span class="frac"><span>${f[0]}</span><span>${f[1]}</span></span>`;
}
