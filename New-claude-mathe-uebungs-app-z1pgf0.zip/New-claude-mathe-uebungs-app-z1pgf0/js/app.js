// Interaktive Übungen: Startseite, fünf Übungen, QR-Code.

const EXERCISES = [
  { id: 'u1', nr: 1, title: 'Bruchteile ablesen', text: 'Welcher Anteil ist gefärbt? Zähler und Nenner eintragen.' },
  { id: 'u2', nr: 2, title: 'Brüche zuordnen', text: 'Ziehe jeden Bruch auf die passende Darstellung.' },
  { id: 'u3', nr: 3, title: 'Flächeninhalt', text: 'Ordne jedem Rechteck seinen Flächeninhalt zu.' },
  { id: 'u4', nr: 4, title: 'Gleich große Vierecke', text: 'Finde Vierecke mit gleichem Flächeninhalt.' },
  { id: 'u5', nr: 5, title: 'Kürzen & Erweitern', text: 'Finde die Brüche, die gleich viel wert sind.' },
];

// ---------- Ziehen & Antippen (Maus, Stift und Touch) ----------
const Drag = (() => {
  let selected = null; // { el, onDrop }

  function clearSelection() {
    if (selected) selected.el.classList.remove('selected');
    selected = null;
  }

  function tap(el, onDrop, targets) {
    if (selected && selected.el === el) return clearSelection();
    if (selected && el.matches(targets)) {
      const s = selected;
      clearSelection();
      return s.onDrop(s.el, el);
    }
    clearSelection();
    selected = { el, onDrop };
    el.classList.add('selected');
  }

  // Ziel antippen, nachdem eine Karte ausgewählt wurde
  function target(el, onDrop) {
    el.addEventListener('click', () => {
      if (!selected) return;
      const s = selected;
      clearSelection();
      onDrop(s.el, el);
    });
  }

  // Bei Touch: kurz gedrückt halten startet das Ziehen, schnelles Wischen scrollt die Seite.
  function source(el, { targets, onDrop }) {
    let armed = false;
    el.addEventListener('touchmove', ev => { if (armed) ev.preventDefault(); }, { passive: false });
    el.addEventListener('contextmenu', ev => ev.preventDefault());
    el.addEventListener('pointerdown', e => {
      if (el.classList.contains('locked') || (e.pointerType === 'mouse' && e.button !== 0)) return;
      if (e.pointerType !== 'touch') e.preventDefault();
      const sx = e.clientX, sy = e.clientY;
      const rect = el.getBoundingClientRect();
      const offX = sx - rect.left, offY = sy - rect.top;
      let ghost = null, over = null, raf = 0, lx = sx, ly = sy, hold = 0;
      armed = e.pointerType !== 'touch';
      if (!armed) {
        hold = setTimeout(() => {
          armed = true;
          el.classList.add('lifted');
          if (navigator.vibrate) navigator.vibrate(15);
        }, 220);
      }
      el.setPointerCapture(e.pointerId);

      const findTarget = (x, y) => {
        const t = document.elementFromPoint(x, y);
        const hit = t && t.closest(targets);
        return hit === el ? null : hit;
      };
      const autoScroll = () => {
        const edge = 60;
        if (ly < edge) window.scrollBy(0, -14);
        else if (ly > innerHeight - edge) window.scrollBy(0, 14);
        raf = requestAnimationFrame(autoScroll);
      };
      const move = ev => {
        lx = ev.clientX; ly = ev.clientY;
        if (!ghost) {
          if (Math.hypot(lx - sx, ly - sy) < 6) return;
          if (!armed) { clearTimeout(hold); return; } // Wischen = Scrollen
          clearSelection();
          ghost = el.cloneNode(true);
          ghost.classList.add('ghost');
          ghost.style.width = rect.width + 'px';
          ghost.style.height = rect.height + 'px';
          document.body.appendChild(ghost);
          el.classList.add('dragging');
          raf = requestAnimationFrame(autoScroll);
        }
        ghost.style.transform = `translate(${lx - offX}px, ${ly - offY}px)`;
        const t = findTarget(lx, ly);
        if (t !== over) {
          if (over) over.classList.remove('over');
          over = t;
          if (over) over.classList.add('over');
        }
      };
      const end = cancelled => {
        clearTimeout(hold);
        armed = false;
        el.classList.remove('lifted');
        el.removeEventListener('pointermove', move);
        el.removeEventListener('pointerup', up);
        el.removeEventListener('pointercancel', cancel);
        cancelAnimationFrame(raf);
        if (over) over.classList.remove('over');
        if (ghost) {
          ghost.remove();
          el.classList.remove('dragging');
          if (!cancelled && over) onDrop(el, over);
        } else if (!cancelled) {
          tap(el, onDrop, targets);
        }
      };
      const up = () => end(false);
      const cancel = () => end(true);
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', cancel);
    });
  }

  return { source, target, clearSelection };
})();

function flash(el, cls, ms = 700) {
  el.classList.remove(cls);
  void el.offsetWidth; // Animation neu starten
  el.classList.add(cls);
  setTimeout(() => el.classList.remove(cls), ms);
}

function header(ex) {
  return `<div class="ex-head"><span class="badge">Übung ${ex.nr}</span><h2>${ex.title}</h2></div>`;
}

function setStatus(el, ok, total, errors) {
  el.innerHTML = `<span class="pill ok">✔ ${ok} / ${total}</span><span class="pill bad">✘ Fehlversuche: ${errors}</span>`;
}

// ---------- Übung 1 ----------
function renderU1(root) {
  const ex = EXERCISES[0];
  root.innerHTML = header(ex) +
    `<p class="intro">Welcher Anteil der Fläche ist <b>gefärbt</b>? Trage oben den <b>Zähler</b> und unten den <b>Nenner</b> ein. Dann auf „Überprüfen" tippen.</p>
     <div class="cards figs"></div>
     <div class="actions"><button class="btn primary" id="check">Überprüfen</button><button class="btn" id="reset">Neu anfangen</button></div>
     <div class="msg" id="msg"></div>`;
  const grid = root.querySelector('.figs');
  EX1.forEach((s, i) => {
    const card = document.createElement('div');
    card.className = 'card fig';
    card.innerHTML = `<span class="num">${i + 1}</span>${shapeSVG(s)}
      <div class="fracin">
        <input inputmode="numeric" pattern="[0-9]*" maxlength="3" aria-label="Zähler Figur ${i + 1}">
        <span class="line"></span>
        <input inputmode="numeric" pattern="[0-9]*" maxlength="3" aria-label="Nenner Figur ${i + 1}">
      </div>`;
    grid.appendChild(card);
  });
  const inputs = [...grid.querySelectorAll('input')];
  inputs.forEach((inp, i) => {
    inp.addEventListener('input', () => {
      inp.value = inp.value.replace(/\D/g, '');
      inp.closest('.card').classList.remove('right', 'wrong');
    });
    inp.addEventListener('keydown', e => {
      if (e.key === 'Enter') { e.preventDefault(); (inputs[i + 1] || root.querySelector('#check')).focus(); }
    });
  });
  root.querySelector('#check').onclick = () => {
    let right = 0, filled = 0;
    [...grid.children].forEach((card, i) => {
      const [z, n] = [...card.querySelectorAll('input')].map(x => parseInt(x.value, 10));
      card.classList.remove('right', 'wrong');
      if (isNaN(z) || isNaN(n)) return;
      filled++;
      if (n > 0 && sameValue([z, n], shapeFraction(EX1[i]))) { right++; card.classList.add('right'); }
      else card.classList.add('wrong');
    });
    const msg = root.querySelector('#msg');
    msg.className = 'msg ' + (right === EX1.length ? 'done' : '');
    msg.textContent = right === EX1.length
      ? '🎉 Super! Alle 20 Anteile richtig!'
      : `${right} von ${EX1.length} richtig.` + (filled < EX1.length ? ` Noch ${EX1.length - filled} Felder leer.` : ' Verbessere die rot markierten Felder.');
  };
  root.querySelector('#reset').onclick = () => renderU1(root);
}

// ---------- Zuordnen (Übung 2 und 3) ----------
function matchExercise(root, ex, cfg) {
  let done = 0, errors = 0;
  root.innerHTML = header(ex) +
    `<p class="intro">${cfg.intro}</p>
     <div class="status"></div>
     <div class="msg"></div>
     <div class="cards targets ${cfg.gridClass || ''}"></div>
     <div class="actions"><button class="btn" id="reset">Neu mischen</button></div>
     <div class="pool"><div class="pool-title">${cfg.poolTitle}</div><div class="pool-cards"></div></div>`;
  const grid = root.querySelector('.targets');
  const pool = root.querySelector('.pool-cards');
  const status = root.querySelector('.status');
  const msg = root.querySelector('.msg');
  const update = () => {
    setStatus(status, done, cfg.targets.length, errors);
    if (done === cfg.targets.length) {
      msg.className = 'msg done';
      msg.textContent = cfg.doneText;
      pool.querySelectorAll('.chip').forEach(c => c.classList.add('leftover'));
    }
  };

  const drop = (card, tgt) => {
    if (tgt.classList.contains('done')) return;
    const c = cfg.cards[card.dataset.i], t = cfg.targets[tgt.dataset.i];
    if (cfg.eq(c.key, t.key)) {
      tgt.querySelector('.slot').appendChild(card);
      card.classList.add('locked');
      tgt.classList.add('done');
      flash(tgt, 'blink', 1300);
      done++;
    } else {
      errors++;
      flash(tgt, 'shake');
      flash(card, 'shake');
    }
    update();
  };

  cfg.targets.forEach((t, i) => {
    const el = document.createElement('div');
    el.className = 'card target';
    el.dataset.i = i;
    el.innerHTML = `<span class="num">${i + 1}</span>${t.html}<div class="slot"></div>`;
    Drag.target(el, drop);
    grid.appendChild(el);
  });
  shuffle(cfg.cards.map((c, i) => i)).forEach(i => {
    const el = document.createElement('div');
    el.className = 'chip';
    el.dataset.i = i;
    el.innerHTML = cfg.cards[i].html;
    Drag.source(el, { targets: '.target:not(.done)', onDrop: drop });
    pool.appendChild(el);
  });
  root.querySelector('#reset').onclick = () => matchExercise(root, ex, cfg);
  update();
}

function renderU2(root) {
  const figs = EX2_FIGS.map(s => ({ html: shapeSVG(s), key: shapeFraction(s) }));
  const cards = [...EX2_FIGS.map(shapeFraction), ...EX2_EXTRA].map(f => ({ html: fracHTML(f), key: f }));
  matchExercise(root, EXERCISES[1], {
    intro: 'Ziehe jeden Bruch auf die passende Darstellung. <b>Achtung:</b> 5 Brüche passen zu keiner Darstellung! <br><small>Tipp: Du kannst auch zuerst einen Bruch und dann die Figur antippen. Auf dem Tablet: Karte kurz festhalten, dann ziehen.</small>',
    poolTitle: 'Brüche',
    targets: figs,
    cards,
    eq: sameValue,
    gridClass: 'figs',
    doneText: '🎉 Geschafft! Die übrigen 5 Brüche passen zu keiner Darstellung.',
  });
}

function renderU3(root) {
  const targets = EX3.map(([w, h]) => ({ html: rectSVG({ w, h }, 9), key: w * h }));
  const cards = EX3.map(([w, h]) => ({ html: `${w * h} cm²`, key: w * h }));
  matchExercise(root, EXERCISES[2], {
    intro: 'Berechne den Flächeninhalt jedes Rechtecks (A = Länge · Breite) und ziehe die passende Karte darauf. <small>(Die Zeichnungen sind verkleinert.)</small>',
    poolTitle: 'Flächeninhalte',
    targets,
    cards,
    eq: (a, b) => a === b,
    gridClass: 'rects',
    doneText: '🎉 Super! Alle Flächeninhalte richtig zugeordnet!',
  });
}

// ---------- Paare finden (Übung 4 und 5) ----------
function pairExercise(root, ex, cfg) {
  let found = 0, errors = 0;
  root.innerHTML = header(ex) +
    `<p class="intro">${cfg.intro}</p>
     <div class="status"></div>
     <div class="cards pitems ${cfg.gridClass}"></div>
     <div class="msg"></div>
     <h3 class="found-title">Gefundene Paare</h3>
     <div class="found"></div>
     <div class="actions"><button class="btn" id="reset">Neu mischen</button></div>`;
  const grid = root.querySelector('.pitems');
  const foundArea = root.querySelector('.found');
  const status = root.querySelector('.status');
  const msg = root.querySelector('.msg');
  const update = () => {
    setStatus(status, found, cfg.pairs, errors);
    if (found === cfg.pairs) {
      grid.querySelectorAll('.pitem').forEach(p => p.classList.add('leftover'));
      msg.className = 'msg done';
      msg.textContent = `🎉 Alle ${cfg.pairs} Paare gefunden! Die übrigen ${cfg.items.length - 2 * cfg.pairs} haben keinen Partner.`;
    }
  };

  const drop = (a, b) => {
    if (a === b || a.classList.contains('locked') || b.classList.contains('locked')) return;
    if (cfg.eq(cfg.items[a.dataset.i].key, cfg.items[b.dataset.i].key)) {
      a.classList.add('locked');
      b.classList.add('locked');
      const pair = document.createElement('div');
      pair.className = 'pair blink-pair';
      b.before(pair);
      pair.append(a, Object.assign(document.createElement('span'), { className: 'eq', textContent: cfg.joiner }), b);
      found++;
      setTimeout(() => {
        pair.classList.remove('blink-pair');
        foundArea.appendChild(pair);
        update();
      }, 1500);
    } else {
      errors++;
      flash(a, 'shake');
      flash(b, 'shake');
    }
    setStatus(status, found, cfg.pairs, errors);
  };

  shuffle(cfg.items.map((x, i) => i)).forEach(i => {
    const el = document.createElement('div');
    el.className = 'pitem';
    el.dataset.i = i;
    el.innerHTML = cfg.items[i].html;
    Drag.source(el, { targets: '.pitem:not(.locked)', onDrop: drop });
    grid.appendChild(el);
  });
  root.querySelector('#reset').onclick = () => pairExercise(root, ex, cfg);
  update();
}

function renderU4(root) {
  const items = [];
  EX4_PAIRS.forEach(p => p.forEach(r => items.push(r)));
  EX4_SINGLES.forEach(r => items.push(r));
  pairExercise(root, EXERCISES[3], {
    intro: 'Welche Vierecke haben den <b>gleichen Flächeninhalt</b>? Ziehe ein Viereck auf seinen Partner (oder tippe beide nacheinander an). <b>5 Vierecke</b> haben keinen Partner. <small>Achte auf die Einheiten! (Zeichnungen verkleinert)</small>',
    items: items.map(r => ({ html: rectSVG(r, 8), key: r.w * r.h })),
    eq: (a, b) => a === b,
    pairs: EX4_PAIRS.length,
    joiner: '=',
    gridClass: 'rects',
  });
}

function renderU5(root) {
  const fr = [];
  EX5_PAIRS.forEach(p => p.forEach(f => fr.push(f)));
  EX5_SINGLES.forEach(f => fr.push(f));
  pairExercise(root, EXERCISES[4], {
    intro: 'Welche Brüche sind <b>gleich viel wert</b>? Kürze oder erweitere im Kopf und ziehe die beiden Brüche aufeinander (oder tippe beide nacheinander an). <b>8 Brüche</b> haben keinen Partner.',
    items: fr.map(f => ({ html: fracHTML(f), key: f })),
    eq: sameValue,
    pairs: EX5_PAIRS.length,
    joiner: '=',
    gridClass: 'fracs',
  });
}

// ---------- Startseite & QR-Code ----------
function appUrl() {
  return location.href.split('#')[0].replace(/index\.html$/, '');
}

function renderHome(root) {
  root.innerHTML = `
    <p class="intro center">Wähle eine Übung aus. Viel Erfolg! 💪</p>
    <div class="tiles">
      ${EXERCISES.map(e => `<a class="tile" href="#/${e.id}"><span class="badge">Übung ${e.nr}</span><b>${e.title}</b><span>${e.text}</span></a>`).join('')}
      <a class="tile alt" href="print.html"><span class="badge">🖨️</span><b>Druckversion</b><span>Alle Übungen als Arbeitsblätter (mit Lösungen).</span></a>
      <a class="tile alt" href="#/qr"><span class="badge">📱</span><b>QR-Code</b><span>So kommen alle schnell zur App.</span></a>
    </div>`;
}

function renderQR(root) {
  root.innerHTML = `
    <div class="ex-head"><h2>QR-Code zur App</h2></div>
    <p class="intro no-print">Scanne den Code mit dem Tablet oder Handy. Du kannst die Adresse unten ändern, falls die App woanders liegt.</p>
    <div class="qrbox">
      <div class="qr-title">Mathe-Training 6 📐</div>
      <div id="qr"></div>
      <div id="qrurl" class="qrurl"></div>
    </div>
    <div class="actions no-print">
      <input id="url" class="urlin" type="url" aria-label="Adresse">
      <button class="btn" id="make">Code erzeugen</button>
      <button class="btn primary" id="printqr">QR-Code drucken</button>
    </div>
    <p class="msg warn no-print" id="qrwarn" hidden>Hinweis: Die App ist gerade nur lokal geöffnet. Damit der QR-Code bei den Kindern funktioniert, muss die App online liegen (z. B. GitHub Pages) – trage dann diese Adresse oben ein.</p>`;
  const input = root.querySelector('#url');
  const make = () => {
    const url = input.value.trim();
    const qr = qrcode(0, 'M');
    qr.addData(url);
    qr.make();
    root.querySelector('#qr').innerHTML = qr.createSvgTag({ cellSize: 8, margin: 2, scalable: true, alt: 'QR-Code zur Mathe-App' });
    root.querySelector('#qrurl').textContent = url;
    root.querySelector('#qrwarn').hidden = /^https?:/.test(url);
  };
  input.value = appUrl();
  root.querySelector('#make').onclick = make;
  input.addEventListener('keydown', e => { if (e.key === 'Enter') make(); });
  root.querySelector('#printqr').onclick = () => window.print();
  make();
}

const VIEWS = { u1: renderU1, u2: renderU2, u3: renderU3, u4: renderU4, u5: renderU5, qr: renderQR };

function route() {
  Drag.clearSelection();
  const id = location.hash.replace(/^#\/?/, '');
  const root = document.getElementById('main');
  document.body.dataset.view = VIEWS[id] ? id : 'home';
  (VIEWS[id] || renderHome)(root);
  const nav = document.getElementById('nav');
  nav.innerHTML = EXERCISES.map(e => `<a href="#/${e.id}" class="${e.id === id ? 'active' : ''}" title="${e.title}">${e.nr}</a>`).join('');
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', route);
route();
