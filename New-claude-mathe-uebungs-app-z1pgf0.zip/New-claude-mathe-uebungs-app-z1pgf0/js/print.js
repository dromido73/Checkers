// Druckversion: Arbeitsblätter für alle fünf Übungen und ein Lösungsblatt.
// Feste Startwerte sorgen dafür, dass Arbeitsblatt und Lösungsblatt immer zusammenpassen.

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const SHEETS = [
  { id: 1, title: 'Bruchteile ablesen' },
  { id: 2, title: 'Brüche zuordnen' },
  { id: 3, title: 'Flächeninhalt von Rechtecken' },
  { id: 4, title: 'Flächeninhaltsgleiche Vierecke' },
  { id: 5, title: 'Kürzen und Erweitern' },
];

const emptyFrac = '<div class="pfrac"><span></span><i></i><span></span></div>';

function sheetHead(nr, title, task) {
  return `<div class="namebar"><span>Name: </span><span>Klasse: </span><span>Datum: </span></div>
    <h2><span class="badge">Übung ${nr}</span> ${title}</h2><p class="task">${task}</p>`;
}

// Gemischte Reihenfolgen (fest)
const P2_CARDS = shuffle([...EX2_FIGS.map(shapeFraction), ...EX2_EXTRA], mulberry32(21));
const P3_AREAS = shuffle(EX3.map(([w, h]) => w * h), mulberry32(31));
const P4_ITEMS = shuffle([
  ...EX4_PAIRS.flatMap((p, pi) => p.map(r => ({ r, pi }))),
  ...EX4_SINGLES.map(r => ({ r, pi: -1 })),
], mulberry32(41));
const P5_ITEMS = shuffle([
  ...EX5_PAIRS.flatMap((p, pi) => p.map(f => ({ f, pi }))),
  ...EX5_SINGLES.map(f => ({ f, pi: -1 })),
], mulberry32(51));

const SHEET_HTML = {
  1: () => sheetHead(1, 'Bruchteile ablesen', 'Welcher Anteil der Fläche ist gefärbt? Schreibe den Bruch in das Kästchen.') +
    `<div class="pgrid c5">${EX1.map((s, i) => `<div class="pcell"><span class="num">${i + 1}</span>${shapeSVG(s)}${emptyFrac}</div>`).join('')}</div>`,

  2: () => sheetHead(2, 'Brüche zuordnen', 'Schreibe unter jede Darstellung den passenden Bruch aus dem Kasten. <b>5 Brüche passen zu keiner Darstellung</b> – kreise sie am Ende ein.') +
    `<div class="pbank">${P2_CARDS.map(fracHTML).join('')}</div>
     <div class="pgrid c5">${EX2_FIGS.map((s, i) => `<div class="pcell"><span class="num">${i + 1}</span>${shapeSVG(s)}${emptyFrac}</div>`).join('')}</div>`,

  3: () => sheetHead(3, 'Flächeninhalt von Rechtecken', 'Berechne den Flächeninhalt (A = Länge · Breite). Jeder Flächeninhalt aus dem Kasten kommt genau einmal vor. <small>(Zeichnungen verkleinert)</small>') +
    `<div class="pbank">${P3_AREAS.map(a => `<span>${a} cm²</span>`).join('')}</div>
     <div class="pgrid c4">${EX3.map(([w, h], i) => `<div class="pcell"><span class="num">${i + 1}</span>${rectSVG({ w, h }, 7.5)}<div class="pline">A = ________ cm²</div></div>`).join('')}</div>`,

  4: () => sheetHead(4, 'Flächeninhaltsgleiche Vierecke', 'Welche Vierecke haben den gleichen Flächeninhalt? Schreibe die Paare auf. <b>5 Vierecke haben keinen Partner.</b> Achte auf die Einheiten! <small>(Zeichnungen verkleinert)</small>') +
    `<div class="pgrid c5">${P4_ITEMS.map((it, i) => `<div class="pcell"><span class="num big">${LETTERS[i]}</span>${rectSVG(it.r, 7.5)}</div>`).join('')}</div>
     <div class="pairs-lines">${EX4_PAIRS.map(() => '<span>____ und ____</span>').join('')}</div>
     <p class="pline left">Ohne Partner: ______________________________</p>`,

  5: () => sheetHead(5, 'Kürzen und Erweitern', 'Welche Brüche sind gleich viel wert? Kürze oder erweitere und schreibe die Paare auf. <b>8 Brüche haben keinen Partner.</b>') +
    `<div class="pgrid c6">${P5_ITEMS.map((it, i) => `<div class="pcell fr"><span class="num">${i + 1}</span>${fracHTML(it.f)}</div>`).join('')}</div>
     <div class="pairs-lines">${EX5_PAIRS.map(() => '<span>____ = ____</span>').join('')}</div>
     <p class="pline left">Ohne Partner: ______________________________</p>`,
};

const SOLUTION_HTML = {
  1: () => `<ol class="sol-list">${EX1.map(s => `<li>${fracHTML(shapeFraction(s))}</li>`).join('')}</ol>`,
  2: () => `<ol class="sol-list">${EX2_FIGS.map(s => `<li>${fracHTML(shapeFraction(s))}</li>`).join('')}</ol>
    <p>Ohne Darstellung: ${EX2_EXTRA.map(fracHTML).join(' ')}</p>`,
  3: () => `<ol class="sol-list wide">${EX3.map(([w, h]) => `<li>${w} · ${h} = <b>${w * h} cm²</b></li>`).join('')}</ol>`,
  4: () => {
    const area = r => r.w * r.h;
    const pairs = EX4_PAIRS.map((p, pi) => {
      const ls = P4_ITEMS.map((it, i) => it.pi === pi ? LETTERS[i] : null).filter(Boolean);
      return `<li><b>${ls.join(' und ')}</b> (${area(p[0])} cm²)</li>`;
    });
    const singles = P4_ITEMS.map((it, i) => it.pi < 0 ? `${LETTERS[i]} (${area(it.r)} cm²)` : null).filter(Boolean);
    return `<ul class="sol-list wide">${pairs.join('')}</ul><p>Ohne Partner: ${singles.join(', ')}</p>`;
  },
  5: () => {
    const pairs = EX5_PAIRS.map((p, pi) => {
      const ns = P5_ITEMS.map((it, i) => it.pi === pi ? i + 1 : null).filter(Boolean);
      return `<li><b>${ns.join(' und ')}</b>: ${fracHTML(p[0])} = ${fracHTML(p[1])}</li>`;
    });
    const singles = P5_ITEMS.map((it, i) => it.pi < 0 ? `${i + 1} (${fracHTML(it.f)})` : null).filter(Boolean);
    return `<ul class="sol-list wide">${pairs.join('')}</ul><p>Ohne Partner: ${singles.join(', ')}</p>`;
  },
};

function qrPage() {
  const url = location.href.split('#')[0].replace(/print\.html.*$/, '');
  const qr = qrcode(0, 'M');
  qr.addData(url);
  qr.make();
  return `<section class="sheet qrsheet"><h2>📐 Mathe-Training 6</h2><p>Scanne den Code mit Tablet oder Handy:</p>
    <div class="qrbig">${qr.createSvgTag({ cellSize: 8, margin: 2, scalable: true })}</div><p class="qrurl">${url}</p></section>`;
}

function render() {
  const chosen = SHEETS.filter(s => document.getElementById('o' + s.id).checked);
  let html = chosen.map(s => `<section class="sheet">${SHEET_HTML[s.id]()}</section>`).join('');
  if (document.getElementById('sol').checked && chosen.length) {
    html += `<section class="sheet solutions"><h2>Lösungen</h2>${chosen.map(s =>
      `<h3>Übung ${s.id}: ${s.title}</h3>${SOLUTION_HTML[s.id]()}`).join('')}</section>`;
  }
  if (document.getElementById('qrpage').checked) html += qrPage();
  document.getElementById('sheets').innerHTML = html;
}

document.getElementById('opts').innerHTML = SHEETS.map(s =>
  `<label><input type="checkbox" id="o${s.id}" checked> Übung ${s.id}: ${s.title}</label>`).join('');
document.querySelectorAll('.controls input').forEach(i => i.addEventListener('change', render));
document.getElementById('print').onclick = () => window.print();
render();
