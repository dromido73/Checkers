// Aufgabendaten für alle fünf Übungen.
// Figuren: t = Typ (circle, grid, bar, hex, tri, half), k = Anzahl gefärbter Teile,
// seed = Zufallsmuster für verstreute Färbung (ohne seed werden die Teile zusammenhängend gefärbt).

// Übung 1: Bruchteile ablesen (20 Flächen, alle Anteile verschieden)
const EX1 = [
  { t: 'circle', n: 4, k: 1 },
  { t: 'grid', r: 2, c: 3, k: 5, seed: 3 },
  { t: 'circle', n: 8, k: 3 },
  { t: 'bar', n: 5, k: 2, seed: 7 },
  { t: 'hex', k: 1 },
  { t: 'grid', r: 3, c: 4, k: 7, seed: 11 },
  { t: 'tri', m: 2, k: 3, seed: 5 },
  { t: 'hex', k: 4, seed: 2 },
  { t: 'grid', r: 2, c: 5, k: 3, seed: 2 },
  { t: 'bar', n: 7, k: 4, seed: 9 },
  { t: 'tri', m: 3, k: 5, seed: 4 },
  { t: 'circle', n: 5, k: 4 },
  { t: 'grid', r: 4, c: 4, k: 9, seed: 8 },
  { t: 'bar', n: 8, k: 7, seed: 1 },
  { t: 'circle', n: 12, k: 5 },
  { t: 'grid', r: 3, c: 3, k: 2, seed: 6 },
  { t: 'half', k: 1 },
  { t: 'grid', r: 4, c: 5, k: 11, seed: 12 },
  { t: 'circle', n: 10, k: 7 },
  { t: 'grid', r: 3, c: 5, k: 4, seed: 13 },
];

// Übung 2: Brüche den Darstellungen zuordnen (20 Figuren + 5 Brüche ohne passende Figur)
const EX2_FIGS = [
  { t: 'circle', n: 2, k: 1 },
  { t: 'bar', n: 3, k: 1, seed: 4 },
  { t: 'circle', n: 5, k: 3 },
  { t: 'bar', n: 7, k: 2, seed: 3 },
  { t: 'grid', r: 2, c: 4, k: 5, seed: 5 },
  { t: 'circle', n: 8, k: 1 },
  { t: 'grid', r: 2, c: 2, k: 3, seed: 1 },
  { t: 'grid', r: 3, c: 3, k: 4, seed: 9 },
  { t: 'bar', n: 5, k: 1, seed: 2 },
  { t: 'hex', k: 5 },
  { t: 'tri', m: 3, k: 7, seed: 3 },
  { t: 'tri', m: 2, k: 1, seed: 2 },
  { t: 'bar', n: 10, k: 9, seed: 6 },
  { t: 'circle', n: 3, k: 2 },
  { t: 'circle', n: 12, k: 7 },
  { t: 'grid', r: 2, c: 4, k: 3, seed: 8 },
  { t: 'grid', r: 3, c: 4, k: 5, seed: 7 },
  { t: 'circle', n: 7, k: 3 },
  { t: 'grid', r: 4, c: 4, k: 11, seed: 4 },
  { t: 'grid', r: 2, c: 5, k: 1, seed: 3 },
];
const EX2_EXTRA = [[2, 5], [4, 7], [3, 10], [5, 7], [7, 8]];

// Übung 3: Rechtecke [Länge, Breite] in cm – alle Flächeninhalte verschieden
const EX3 = [
  [4, 3], [5, 2], [6, 6], [3, 7], [8, 5], [9, 2], [4, 4], [10, 3], [2, 12], [7, 7],
  [9, 5], [8, 7], [11, 4], [5, 5], [13, 2], [6, 8], [15, 4], [9, 9], [7, 2], [12, 6],
];

// Übung 4: Flächeninhaltsgleiche Vierecke – 10 Paare + 5 Vierecke ohne Partner.
// w/h = Länge/Breite in cm (für die Zeichnung), wl/hl = abweichende Beschriftung (andere Einheit)
const EX4_PAIRS = [
  [{ w: 9, h: 4 }, { w: 6, h: 6 }],
  [{ w: 8, h: 3 }, { w: 12, h: 2 }],
  [{ w: 8, h: 5 }, { w: 10, h: 4, wl: '1 dm' }],
  [{ w: 8, h: 6 }, { w: 12, h: 4 }],
  [{ w: 8, h: 8 }, { w: 16, h: 4 }],
  [{ w: 6, h: 5 }, { w: 10, h: 3 }],
  [{ w: 9, h: 2, hl: '20 mm' }, { w: 6, h: 3 }],
  [{ w: 10, h: 6 }, { w: 12, h: 5 }],
  [{ w: 4, h: 4 }, { w: 8, h: 2 }],
  [{ w: 5, h: 4 }, { w: 10, h: 2 }],
];
const EX4_SINGLES = [{ w: 7, h: 5 }, { w: 9, h: 3 }, { w: 7, h: 7 }, { w: 11, h: 2 }, { w: 7, h: 6 }];

// Übung 5: Kürzen und Erweitern – 11 Paare (22 Brüche) + 8 Brüche ohne Partner
const EX5_PAIRS = [
  [[1, 2], [4, 8]],
  [[6, 9], [10, 15]],
  [[3, 4], [15, 20]],
  [[2, 5], [6, 15]],
  [[5, 6], [20, 24]],
  [[3, 7], [9, 21]],
  [[4, 9], [12, 27]],
  [[7, 10], [21, 30]],
  [[1, 3], [5, 15]],
  [[5, 8], [25, 40]],
  [[9, 15], [12, 20]],
];
const EX5_SINGLES = [[8, 10], [3, 8], [5, 9], [7, 12], [4, 14], [9, 16], [3, 18], [10, 24]];
